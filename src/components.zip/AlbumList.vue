<template>
  <div class="list">
    <!-- <ul class="albumList" v-if="!showAlbum">
      <li v-for="(item, index) in recommAlbumList" :key="index">
        <div @click="showRecommAblum(item.id)">
          <span class="order">{{ index + 1 }}</span>
          <img class="listImg" :src="item.picUrl" />
          {{ item.name }}
        </div>
      </li>
    </ul> -->
    <list
      v-if="!showAlbum"
      :listData="recommAlbumList"
      @getMusicID="showRecommAblum"
    ></list>
    <div class="albumDetail" v-if="showAlbum">
      <button @click="showAlbum = !showAlbum">返回</button>

      <div class="description">
        <div class="coverPic">
          <img :src="albumDetail.coverImgUrl" />
        </div>
        <div class="infos">
          <h2 class="infosTitle">{{ albumDetail.name }}</h2>
          <p>{{ albumDetail.description }}</p>
        </div>
      </div>
      <list :listData="albumList"></list>
    </div>
  </div>
</template>
<script>
import { mapState } from "vuex";
import List from "./List";
export default {
  name: "AlbumList",
  data() {
    return {
      albumList: [],
      showAlbum: false,
      albumDetail: [],
    };
  },
  methods: {
    showRecommAblum(id) {
      this.axios
        .get("/playlist/detail/dynamic?id=" + id)
        .then((result) => {
          // console.log(result);
          this.albumDetail = result.data.playlist;
          console.log(this.albumDetail);
          this.showAlbum = true;
        })
        .catch((err) => {});
    },
    sendAlbumDetail() {
      console.log(this.albumDetail);
      this.albumDetail.tracks.forEach((v) => {
        this.albumList.push({
          name: v.name,
          id: v.id,
          picUrl: v.al.picUrl,
          album: false,
          artist: v.ar[0].name,
          artistID: v.ar[0].id,
          duration: v.dt,
        });
      });
      console.log(this.albumList);
    },
  },
  computed: {
    ...mapState(["recommAlbumList"]),
  },
  components: {
    List,
  },
};
</script>
<style scoped>
/* 歌单详情 */
.albumDetail .description {
  display: flex;
  flex-direction: row;
}
.coverPic img {
  height: 100px;
  width: 100px;
  border-radius: 10px;
}

/* 推荐歌单 */
.list {
  width: 100%;
  height: calc(100vh - 90px);
  border-left: 1px solid rgba(255, 255, 255, 0.2);
  background: rgba(0, 0, 0, 0.2);
  display: flex;
  justify-content: center;
  flex-direction: column;
  text-align: left;
}
</style>
